Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/hcsr04_simpletest.py
    :caption: examples/hcsr04_simpletest.py
    :linenos:
